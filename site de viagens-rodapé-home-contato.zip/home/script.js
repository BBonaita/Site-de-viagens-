  function showModal0(){
  var element = document.getElementById("modal0");
  element.classList.add("show-modal0");
  }
  function hideModal0(){
      var element = document.getElementById("modal0");
      element.classList.remove("show-modal0");
  } 

  // CARDS:
  // atribui a classe modal à função show-modal (abrindo pelo "add" e fechando pelo "remove")
      function showModal(){
      var element = document.getElementById("modal");
      element.classList.add("show-modal");
      }
      function hideModal(){
          var element = document.getElementById("modal");
          element.classList.remove("show-modal");
      }
      // ITÁLIA - 1
      function showModal1(){
      var element = document.getElementById("modal1");
      element.classList.add("show-modal1");
      }
      function hideModal1(){
          var element = document.getElementById("modal1");
          element.classList.remove("show-modal1");
      }
      // NORUEGA - 2
      function showModal2(){
      var element = document.getElementById("modal2");
      element.classList.add("show-modal2");
      }
      function hideModal2(){
          var element = document.getElementById("modal2");
          element.classList.remove("show-modal2");
      }
      // GRÉCIA - 3
      function showModal3(){
      var element = document.getElementById("modal3");
      element.classList.add("show-modal3");
      }
      function hideModal3(){
          var element = document.getElementById("modal3");
          element.classList.remove("show-modal3");
      }
      // EGITO - 4
      function showModal4(){
      var element = document.getElementById("modal4");
      element.classList.add("show-modal4");
      }
      function hideModal4(){
          var element = document.getElementById("modal4");
          element.classList.remove("show-modal4");
      }
      // HOLANDA - 5
      function showModal5(){
      var element = document.getElementById("modal5");
      element.classList.add("show-modal5");
      }
      function hideModal5(){
          var element = document.getElementById("modal5");
          element.classList.remove("show-modal5");
      }
      // JAPÃO - 6
      function showModal6(){
      var element = document.getElementById("modal6");
      element.classList.add("show-modal6");
      }
      function hideModal6(){
          var element = document.getElementById("modal6");
          element.classList.remove("show-modal6");
      }
      // FRANÇA - 7
      function showModal7(){
      var element = document.getElementById("modal7");
      element.classList.add("show-modal7");
      }
      function hideModal7(){
          var element = document.getElementById("modal7");
          element.classList.remove("show-modal7");
      }
      // AUSTRÁLIA - 8
      function showModal8(){
      var element = document.getElementById("modal8");
      element.classList.add("show-modal8");
      }
      function hideModal8(){
          var element = document.getElementById("modal8");
          element.classList.remove("show-modal8");
      }