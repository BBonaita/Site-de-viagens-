function showModal0(){
var element = document.getElementById("modal0");
element.classList.add("show-modal0");
}
function hideModal0(){
    var element = document.getElementById("modal0");
    element.classList.remove("show-modal0");
} 